Model Paralell LSTM
===================
This is an example showing how to do model parallel LSTM in MXNet.
Most of the code is duplicated with the rnn example, and should be eventually merged.
