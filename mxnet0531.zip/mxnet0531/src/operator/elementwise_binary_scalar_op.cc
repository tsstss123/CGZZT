/*!
 * Copyright (c) 2015 by Contributors
 * \file elementwise_binary_scalar_op.cc
 * \brief elementwise binary operator
*/
#include "./elementwise_binary_scalar_op-inl.h"
