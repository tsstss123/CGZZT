/*!
 * Copyright (c) 2015 by Contributors
 * \file smooth_l1_unary.cc
 * \brief Smooth L1 loss
*/
#include "./smooth_l1_unary-inl.h"
