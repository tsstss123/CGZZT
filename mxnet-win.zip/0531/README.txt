1.用管理员身份运行setupenv.cmd自动设置环境变量
environment up yourselves, refer to setupenv.cmd for more information.
2.安装python支持
cd python
python setup.py install

如果一切顺利
C:\> python
>>> import mxnet as mx
>>> a=mx.nd.zeros((2,3))
>>> print(a.asnumpy())
[[0. 0. 0.]
 [0. 0. 0.]]


